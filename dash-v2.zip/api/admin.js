/**
 * |-| [- |_ | /\ ( ~|~ `/ |_
 *
 * Atyro Dash v1
 *
 * This is for the admin side of Heliactyl.
 * @module admin
 */

const settings = require("../settings.json");

if (settings.pterodactyl)
  if (settings.pterodactyl.domain) {
    if (settings.pterodactyl.domain.slice(-1) == "/")
      settings.pterodactyl.domain = settings.pterodactyl.domain.slice(0, -1);
  }

const fs = require("fs");
const indexjs = require("../app.js");
const adminjs = require("./admin.js");
const ejs = require("ejs");
const log = require("../misc/log");

module.exports.load = async function (app, db) {
  app.get("/settings/update", async (req, res) => {
    if (!req.session.pterodactyl || !req.session.pterodactyl.root_admin) {
      return res.status(403).send("Unauthorized");
    }

    const setting = req.query.setting;
    const value = req.query.value;

    if (!setting || !value) {
      return res.status(400).send("Missing setting or value parameter");
    }

    try {
      const settingsPath = "./settings.json";
      const settings = JSON.parse(fs.readFileSync(settingsPath));

      const keys = setting.split(".");
      let currentObj = settings;
      for (let i = 0; i < keys.length - 1; i++) {
        if (!currentObj[keys[i]]) {
          currentObj[keys[i]] = {};
        }
        currentObj = currentObj[keys[i]];
      }
      currentObj[keys[keys.length - 1]] = value;

      fs.writeFileSync(settingsPath, JSON.stringify(settings, null, 2));
      res.send("Settings updated successfully");
    } catch (err) {
      console.error(err);
      res.status(500).send("Internal Server Error");
    }
  });
  
  app.get("/setcoins", async (req, res) => {
    let theme = indexjs.get(req);

    if (!req.session.pterodactyl) return four0four(req, res, theme);

    let cacheaccount = await fetch(
      settings.pterodactyl.domain +
        "/api/application/users/" +
        (await db.get("users-" + req.session.userinfo.id)) +
        "?include=servers",
      {
        method: "get",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${settings.pterodactyl.key}`,
        },
      }
    );
    if ((await cacheaccount.statusText) == "Not Found")
      return four0four(req, res, theme);
    let cacheaccountinfo = JSON.parse(await cacheaccount.text());

    req.session.pterodactyl = cacheaccountinfo.attributes;
    if (cacheaccountinfo.attributes.root_admin !== true)
      return four0four(req, res, theme);

    let failredirect = theme.settings.redirect.failedsetcoins || "/";

    let id = req.query.id;
    let coins = req.query.coins;

    if (!id) return res.redirect(failredirect + "?err=MISSINGID");
    if (!(await db.get("users-" + req.query.id)))
      return res.redirect(`${failredirect}?err=INVALIDID`);

    if (!coins) return res.redirect(failredirect + "?err=MISSINGCOINS");

    coins = parseFloat(coins);

    if (isNaN(coins))
      return res.redirect(failredirect + "?err=INVALIDCOINNUMBER");

    if (coins < 0 || coins > 999999999999999)
      return res.redirect(`${failredirect}?err=COINSIZE`);

    if (coins == 0) {
      await db.delete("coins-" + id);
    } else {
      await db.set("coins-" + id, coins);
    }

    let successredirect = theme.settings.redirect.setcoins || "/";
    log(
      `set coins`,
      `${req.session.userinfo.username}#${req.session.userinfo.discriminator} set the coins of the user with the ID \`${id}\` to \`${coins}\`.`
    );
    res.redirect(successredirect + "?err=none");
  });

  app.get("/addcoins", async (req, res) => {
    let theme = indexjs.get(req);

    if (!req.session.pterodactyl) return four0four(req, res, theme);

    let cacheaccount = await fetch(
      settings.pterodactyl.domain +
        "/api/application/users/" +
        (await db.get("users-" + req.session.userinfo.id)) +
        "?include=servers",
      {
        method: "get",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${settings.pterodactyl.key}`,
        },
      }
    );
    if ((await cacheaccount.statusText) == "Not Found")
      return four0four(req, res, theme);
    let cacheaccountinfo = JSON.parse(await cacheaccount.text());

    req.session.pterodactyl = cacheaccountinfo.attributes;
    if (cacheaccountinfo.attributes.root_admin !== true)
      return four0four(req, res, theme);

    let failredirect = theme.settings.redirect.failedsetcoins || "/";

    let id = req.query.id;
    let coins = req.query.coins;

    if (!id) return res.redirect(failredirect + "?err=MISSINGID");
    if (!(await db.get("users-" + req.query.id)))
      return res.redirect(`${failredirect}?err=INVALIDID`);

    if (!coins) return res.redirect(failredirect + "?err=MISSINGCOINS");

    let currentcoins = (await db.get("coins-" + id)) || 0;

    coins = currentcoins + parseFloat(coins);

    if (isNaN(coins))
      return res.redirect(failredirect + "?err=INVALIDCOINNUMBER");

    if (coins < 0 || coins > 999999999999999)
      return res.redirect(`${failredirect}?err=COINSIZE`);

    if (coins == 0) {
      await db.delete("coins-" + id);
    } else {
      await db.set("coins-" + id, coins);
    }

    let successredirect = theme.settings.redirect.setcoins || "/";
    log(
      `add coins`,
      `${req.session.userinfo.username}#${req.session.userinfo.discriminator} added \`${req.query.coins}\` coins to the user with the ID \`${id}\`'s account.`
    );
    res.redirect(successredirect + "?err=none");
  });

  app.get("/setresources", async (req, res) => {
    let theme = indexjs.get(req);

    if (!req.session.pterodactyl) return four0four(req, res, theme);

    let cacheaccount = await fetch(
      settings.pterodactyl.domain +
        "/api/application/users/" +
        (await db.get("users-" + req.session.userinfo.id)) +
        "?include=servers",
      {
        method: "get",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${settings.pterodactyl.key}`,
        },
      }
    );
    if ((await cacheaccount.statusText) == "Not Found")
      return four0four(req, res, theme);
    let cacheaccountinfo = JSON.parse(await cacheaccount.text());

    req.session.pterodactyl = cacheaccountinfo.attributes;
    if (cacheaccountinfo.attributes.root_admin !== true)
      return four0four(req, res, theme);

    let failredirect = theme.settings.redirect.failedsetresources || "/";

    if (!req.query.id) return res.redirect(`${failredirect}?err=MISSINGID`);

    if (!(await db.get("users-" + req.query.id)))
      return res.redirect(`${failredirect}?err=INVALIDID`);

    let successredirect = theme.settings.redirect.setresources || "/";

    if (req.query.ram || req.query.disk || req.query.cpu || req.query.servers) {
      let ramstring = req.query.ram;
      let diskstring = req.query.disk;
      let cpustring = req.query.cpu;
      let serversstring = req.query.servers;
      let id = req.query.id;

      let currentextra = await db.get("extra-" + req.query.id);
      let extra;

      if (typeof currentextra == "object") {
        extra = currentextra;
      } else {
        extra = {
          ram: 0,
          disk: 0,
          cpu: 0,
          servers: 0,
        };
      }

      if (ramstring) {
        let ram = parseFloat(ramstring);
        if (ram < 0 || ram > 999999999999999) {
          return res.redirect(`${failredirect}?err=RAMSIZE`);
        }
        extra.ram = ram;
      }

      if (diskstring) {
        let disk = parseFloat(diskstring);
        if (disk < 0 || disk > 999999999999999) {
          return res.redirect(`${failredirect}?err=DISKSIZE`);
        }
        extra.disk = disk;
      }

      if (cpustring) {
        let cpu = parseFloat(cpustring);
        if (cpu < 0 || cpu > 999999999999999) {
          return res.redirect(`${failredirect}?err=CPUSIZE`);
        }
        extra.cpu = cpu;
      }

      if (serversstring) {
        let servers = parseFloat(serversstring);
        if (servers < 0 || servers > 999999999999999) {
          return res.redirect(`${failredirect}?err=SERVERSIZE`);
        }
        extra.servers = servers;
      }

      if (
        extra.ram == 0 &&
        extra.disk == 0 &&
        extra.cpu == 0 &&
        extra.servers == 0
      ) {
        await db.delete("extra-" + req.query.id);
      } else {
        await db.set("extra-" + req.query.id, extra);
      }

      adminjs.suspend(req.query.id);

      log(
        `set resources`,
        `${req.session.userinfo.username}#${req.session.userinfo.discriminator} set the resources of the user with the ID \`${id}\` to:\`\`\`servers: ${serversstring}\nCPU: ${cpustring}%\nMemory: ${ramstring} MB\nDisk: ${diskstring} MB\`\`\``
      );
      return res.redirect(successredirect + "?err=none");
    } else {
      res.redirect(`${failredirect}?err=MISSINGVARIABLES`);
    }
  });

  app.get("/addresources", async (req, res) => {
    let theme = indexjs.get(req);

    if (!req.session.pterodactyl) return four0four(req, res, theme);

    let cacheaccount = await fetch(
      settings.pterodactyl.domain +
        "/api/application/users/" +
        (await db.get("users-" + req.session.userinfo.id)) +
        "?include=servers",
      {
        method: "get",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${settings.pterodactyl.key}`,
        },
      }
    );
    if ((await cacheaccount.statusText) == "Not Found")
      return four0four(req, res, theme);
    let cacheaccountinfo = JSON.parse(await cacheaccount.text());

    req.session.pterodactyl = cacheaccountinfo.attributes;
    if (cacheaccountinfo.attributes.root_admin !== true)
      return four0four(req, res, theme);

    let failredirect = theme.settings.redirect.failedsetresources
      ? theme.settings.redirect.failedsetresources
      : "/";

    if (!req.query.id) return res.redirect(`${failredirect}?err=MISSINGID`);

    if (!(await db.get("users-" + req.query.id)))
      return res.redirect(`${failredirect}?err=INVALIDID`);

    let successredirect = theme.settings.redirect.setresources
      ? theme.settings.redirect.setresources
      : "/";

    if (req.query.ram || req.query.disk || req.query.cpu || req.query.servers) {
      let ramstring = req.query.ram;
      let diskstring = req.query.disk;
      let cpustring = req.query.cpu;
      let serversstring = req.query.servers;

      let currentextra = await db.get("extra-" + req.query.id);
      let extra;

      if (typeof currentextra == "object") {
        extra = currentextra;
      } else {
        extra = {
          ram: 0,
          disk: 0,
          cpu: 0,
          servers: 0,
        };
      }

      if (ramstring) {
        let ram = parseFloat(ramstring);
        if (ram < 0 || ram > 999999999999999) {
          return res.redirect(`${failredirect}?err=RAMSIZE`);
        }
        extra.ram = extra.ram + ram;
      }

      if (diskstring) {
        let disk = parseFloat(diskstring);
        if (disk < 0 || disk > 999999999999999) {
          return res.redirect(`${failredirect}?err=DISKSIZE`);
        }
        extra.disk = extra.disk + disk;
      }

      if (cpustring) {
        let cpu = parseFloat(cpustring);
        if (cpu < 0 || cpu > 999999999999999) {
          return res.redirect(`${failredirect}?err=CPUSIZE`);
        }
        extra.cpu = extra.cpu + cpu;
      }

      if (serversstring) {
        let servers = parseFloat(serversstring);
        if (servers < 0 || servers > 999999999999999) {
          return res.redirect(`${failredirect}?err=SERVERSIZE`);
        }
        extra.servers = extra.servers + servers;
      }

      if (
        extra.ram == 0 &&
        extra.disk == 0 &&
        extra.cpu == 0 &&
        extra.servers == 0
      ) {
        await db.delete("extra-" + req.query.id);
      } else {
        await db.set("extra-" + req.query.id, extra);
      }

      adminjs.suspend(req.query.id);
      return res.redirect(successredirect + "?err=none");
    } else {
      res.redirect(`${failredirect}?err=MISSINGVARIABLES`);
    }
  });

  app.get("/setplan", async (req, res) => {
    let theme = indexjs.get(req);

    if (!req.session.pterodactyl) return four0four(req, res, theme);

    let cacheaccount = await fetch(
      settings.pterodactyl.domain +
        "/api/application/users/" +
        (await db.get("users-" + req.session.userinfo.id)) +
        "?include=servers",
      {
        method: "get",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${settings.pterodactyl.key}`,
        },
      }
    );
    if ((await cacheaccount.statusText) == "Not Found")
      return four0four(req, res, theme);
    let cacheaccountinfo = JSON.parse(await cacheaccount.text());

    req.session.pterodactyl = cacheaccountinfo.attributes;
    if (cacheaccountinfo.attributes.root_admin !== true)
      return four0four(req, res, theme);

    let failredirect = theme.settings.redirect.failedsetplan || "/";

    if (!req.query.id) return res.redirect(`${failredirect}?err=MISSINGID`);

    if (!(await db.get("users-" + req.query.id)))
      return res.redirect(`${failredirect}?err=INVALIDID`);

    let successredirect = theme.settings.redirect.setplan || "/";

    if (!req.query.package) {
      await db.delete("package-" + req.query.id);
      adminjs.suspend(req.query.id);

      log(
        `set plan`,
        `${req.session.userinfo.username}#${req.session.userinfo.discriminator} removed the plan of the user with the ID \`${req.query.id}\`.`
      );
      return res.redirect(successredirect + "?err=none");
    } else {
      let newsettings = JSON.parse(
        fs.readFileSync("./settings.json").toString()
      );
      if (!newsettings.api.client.packages.list[req.query.package])
        return res.redirect(`${failredirect}?err=INVALIDPACKAGE`);
      await db.set("package-" + req.query.id, req.query.package);
      adminjs.suspend(req.query.id);

      log(
        `set plan`,
        `${req.session.userinfo.username}#${req.session.userinfo.discriminator} set the plan of the user with the ID \`${req.query.id}\` to \`${req.query.package}\`.`
      );
      return res.redirect(successredirect + "?err=none");
    }
  });

  app.get("/create_coupon", async (req, res) => {
    let theme = indexjs.get(req);

    if (!req.session.pterodactyl) return four0four(req, res, theme);

    let cacheaccount = await fetch(
      settings.pterodactyl.domain +
        "/api/application/users/" +
        (await db.get("users-" + req.session.userinfo.id)) +
        "?include=servers",
      {
        method: "get",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${settings.pterodactyl.key}`,
        },
      }
    );
    if ((await cacheaccount.statusText) == "Not Found")
      return four0four(req, res, theme);
    let cacheaccountinfo = JSON.parse(await cacheaccount.text());

    req.session.pterodactyl = cacheaccountinfo.attributes;
    if (cacheaccountinfo.attributes.root_admin !== true)
      return four0four(req, res, theme);

    let code = req.query.code
      ? req.query.code.slice(0, 200)
      : Math.random().toString(36).substring(2, 15);

    if (!code.match(/^[a-z0-9]+$/i))
      return res.redirect(
        theme.settings.redirect.couponcreationfailed +
          "?err=CREATECOUPONINVALIDCHARACTERS"
      );

    let coins = req.query.coins || 0;
    let ram = req.query.ram * 1024 || 0;
    let disk = req.query.disk * 1024 || 0;
    let cpu = req.query.cpu * 100 || 0;
    let servers = req.query.servers || 0;

    coins = parseFloat(coins);
    ram = parseFloat(ram);
    disk = parseFloat(disk);
    cpu = parseFloat(cpu);
    servers = parseFloat(servers);

    if (coins < 0)
      return res.redirect(
        theme.settings.redirect.couponcreationfailed +
          "?err=CREATECOUPONLESSTHANONE"
      );
    if (ram < 0)
      return res.redirect(
        theme.settings.redirect.couponcreationfailed +
          "?err=CREATECOUPONLESSTHANONE"
      );
    if (disk < 0)
      return res.redirect(
        theme.settings.redirect.couponcreationfailed +
          "?err=CREATECOUPONLESSTHANONE"
      );
    if (cpu < 0)
      return res.redirect(
        theme.settings.redirect.couponcreationfailed +
          "?err=CREATECOUPONLESSTHANONE"
      );
    if (servers < 0)
      return res.redirect(
        theme.settings.redirect.couponcreationfailed +
          "?err=CREATECOUPONLESSTHANONE"
      );

    if (!coins && !ram && !disk && !cpu && !servers)
      return res.redirect(
        theme.settings.redirect.couponcreationfailed + "?err=CREATECOUPONEMPTY"
      );

    await db.set("coupon-" + code, {
      coins: coins,
      ram: ram,
      disk: disk,
      cpu: cpu,
      servers: servers,
    });

    log(
      `create coupon`,
      `${req.session.userinfo.username}#${req.session.userinfo.discriminator} created the coupon code \`${code}\` which gives:\`\`\`coins: ${coins}\nMemory: ${ram} MB\nDisk: ${disk} MB\nCPU: ${cpu}%\nServers: ${servers}\`\`\``
    );
    res.redirect(
      theme.settings.redirect.couponcreationsuccess + "?code=" + code
    );
  });

  app.get("/revoke_coupon", async (req, res) => {
    let theme = indexjs.get(req);

    if (!req.session.pterodactyl) return four0four(req, res, theme);

    let cacheaccount = await fetch(
      settings.pterodactyl.domain +
        "/api/application/users/" +
        (await db.get("users-" + req.session.userinfo.id)) +
        "?include=servers",
      {
        method: "get",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${settings.pterodactyl.key}`,
        },
      }
    );
    if ((await cacheaccount.statusText) == "Not Found")
      return four0four(req, res, theme);
    let cacheaccountinfo = JSON.parse(await cacheaccount.text());

    req.session.pterodactyl = cacheaccountinfo.attributes;
    if (cacheaccountinfo.attributes.root_admin !== true)
      return four0four(req, res, theme);

    let code = req.query.code;

    if (!code.match(/^[a-z0-9]+$/i))
      return res.redirect(
        theme.settings.redirect.couponrevokefailed +
          "?err=REVOKECOUPONCANNOTFINDCODE"
      );

    if (!(await db.get("coupon-" + code)))
      return res.redirect(
        theme.settings.redirect.couponrevokefailed +
          "?err=REVOKECOUPONCANNOTFINDCODE"
      );

    await db.delete("coupon-" + code);

    log(
      `revoke coupon`,
      `${req.session.userinfo.username}#${req.session.userinfo.discriminator} revoked the coupon code \`${code}\`.`
    );
    res.redirect(
      theme.settings.redirect.couponrevokesuccess + "?revokedcode=true"
    );
  });

  app.get("/remove_account", async (req, res) => {
    let theme = indexjs.get(req);

    if (!req.session.pterodactyl) return four0four(req, res, theme);

    let cacheaccount = await fetch(
      settings.pterodactyl.domain +
        "/api/application/users/" +
        (await db.get("users-" + req.session.userinfo.id)) +
        "?include=servers",
      {
        method: "get",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${settings.pterodactyl.key}`,
        },
      }
    );
    if ((await cacheaccount.statusText) == "Not Found")
      return four0four(req, res, theme);
    let cacheaccountinfo = JSON.parse(await cacheaccount.text());

    req.session.pterodactyl = cacheaccountinfo.attributes;
    if (cacheaccountinfo.attributes.root_admin !== true)
      return four0four(req, res, theme);

    // This doesn't delete the account and doesn't touch the renewal system.

    if (!req.query.id)
      return res.redirect(
        theme.settings.redirect.removeaccountfailed +
          "?err=REMOVEACCOUNTMISSINGID"
      );

    let discordid = req.query.id;
    let pteroid = await db.get("users-" + discordid);

    // Remove IP.

    let selected_ip = await db.get("ip-" + discordid);

    if (selected_ip) {
      let allips = (await db.get("ips")) || [];
      allips = allips.filter((ip) => ip !== selected_ip);

      if (allips.length == 0) {
        await db.delete("ips");
      } else {
        await db.set("ips", allips);
      }

      await db.delete("ip-" + discordid);
    }

    // Remove user.

    let userids = (await db.get("users")) || [];
    userids = userids.filter((user) => user !== pteroid);

    if (userids.length == 0) {
      await db.delete("users");
    } else {
      await db.set("users", userids);
    }

    await db.delete("users-" + discordid);

    // Remove coins/resources.

    await db.delete("coins-" + discordid);
    await db.delete("extra-" + discordid);
    await db.delete("package-" + discordid);

    log(
      `remove account`,
      `${req.session.userinfo.username}#${req.session.userinfo.discriminator} removed the account with the ID \`${discordid}\`.`
    );
    res.redirect(
      theme.settings.redirect.removeaccountsuccess + "?success=REMOVEACCOUNT"
    );
  });

  app.get("/getip", async (req, res) => {
    let theme = indexjs.get(req);

    if (!req.session.pterodactyl) return four0four(req, res, theme);

    let cacheaccount = await fetch(
      settings.pterodactyl.domain +
        "/api/application/users/" +
        (await db.get("users-" + req.session.userinfo.id)) +
        "?include=servers",
      {
        method: "get",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${settings.pterodactyl.key}`,
        },
      }
    );
    if ((await cacheaccount.statusText) == "Not Found")
      return four0four(req, res, theme);
    let cacheaccountinfo = JSON.parse(await cacheaccount.text());

    req.session.pterodactyl = cacheaccountinfo.attributes;
    if (cacheaccountinfo.attributes.root_admin !== true)
      return four0four(req, res, theme);

    let failredirect = theme.settings.redirect.failedgetip || "/";
    let successredirect = theme.settings.redirect.getip || "/";
    if (!req.query.id) return res.redirect(`${failredirect}?err=MISSINGID`);

    if (!(await db.get("users-" + req.query.id)))
      return res.redirect(`${failredirect}?err=INVALIDID`);

    if (!(await db.get("ip-" + req.query.id)))
      return res.redirect(`${failredirect}?err=NOIP`);
    let ip = await db.get("ip-" + req.query.id);
    log(
      `view ip`,
      `${req.session.userinfo.username}#${req.session.userinfo.discriminator} viewed the IP of the account with the ID \`${req.query.id}\`.`
    );
    return res.redirect(successredirect + "?err=NONE&ip=" + ip);
  });

  app.get("/userinfo", async (req, res) => {
    let theme = indexjs.get(req);

    if (!req.session.pterodactyl) return four0four(req, res, theme);

    let cacheaccount = await fetch(
      settings.pterodactyl.domain +
        "/api/application/users/" +
        (await db.get("users-" + req.session.userinfo.id)) +
        "?include=servers",
      {
        method: "get",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${settings.pterodactyl.key}`,
        },
      }
    );
    if ((await cacheaccount.statusText) == "Not Found")
      return four0four(req, res, theme);
    let cacheaccountinfo = JSON.parse(await cacheaccount.text());

    req.session.pterodactyl = cacheaccountinfo.attributes;
    if (cacheaccountinfo.attributes.root_admin !== true)
      return four0four(req, res, theme);

    if (!req.query.id) return res.send({ status: "missing id" });

    if (!(await db.get("users-" + req.query.id)))
      return res.send({ status: "invalid id" });

    let newsettings = JSON.parse(fs.readFileSync("./settings.json").toString());

    if (newsettings.api.client.oauth2.link.slice(-1) == "/")
      newsettings.api.client.oauth2.link =
        newsettings.api.client.oauth2.link.slice(0, -1);

    if (newsettings.api.client.oauth2.callbackpath.slice(0, 1) !== "/")
      newsettings.api.client.oauth2.callbackpath =
        "/" + newsettings.api.client.oauth2.callbackpath;

    if (newsettings.pterodactyl.domain.slice(-1) == "/")
      newsettings.pterodactyl.domain = newsettings.pterodactyl.domain.slice(
        0,
        -1
      );

    let packagename = await db.get("package-" + req.query.id);
    let package =
      newsettings.api.client.packages.list[
        packagename ? packagename : newsettings.api.client.packages.default
      ];
    if (!package)
      package = {
        ram: 0,
        disk: 0,
        cpu: 0,
        servers: 0,
      };

    package["name"] = packagename;

    let pterodactylid = await db.get("users-" + req.query.id);
    let userinforeq = await fetch(
      newsettings.pterodactyl.domain +
        "/api/application/users/" +
        pterodactylid +
        "?include=servers",
      {
        method: "get",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${newsettings.pterodactyl.key}`,
        },
      }
    );
    if ((await userinforeq.statusText) == "Not Found") {
      console.log(
        "App ― An error has occured while attempting to get a user's information"
      );
      console.log("- Discord ID: " + req.query.id);
      console.log("- Pterodactyl Panel ID: " + pterodactylid);
      return res.send({ status: "could not find user on panel" });
    }
    let userinfo = await userinforeq.json();

    res.send({
      status: "success",
      package: package,
      extra: (await db.get("extra-" + req.query.id))
        ? await db.get("extra-" + req.query.id)
        : {
            ram: 0,
            disk: 0,
            cpu: 0,
            servers: 0,
          },
      userinfo: userinfo,
      coins:
        newsettings.api.client.coins.enabled == true
          ? (await db.get("coins-" + req.query.id))
            ? await db.get("coins-" + req.query.id)
            : 0
          : null,
    });
  });

  // API endpoint to get admin dashboard stats
  app.get("/api/admin/stats", async (req, res) => {
    if (!req.session.pterodactyl || !req.session.pterodactyl.root_admin) {
      return res.status(403).json({ error: "Unauthorized" });
    }

    try {
      const newsettings = JSON.parse(fs.readFileSync("./settings.json").toString());

      // Total users from local DB
      const usersList = (await db.get("users")) || [];
      const totalUsers = usersList.length;

      // Fetch servers from Pterodactyl panel (paginated to be safe)
      let totalServers = 0;
      let activeServers = 0;
      try {
        const serversResponse = await fetch(
          `${newsettings.pterodactyl.domain}/api/application/servers?per_page=1000`,
          {
            method: "get",
            headers: {
              "Content-Type": "application/json",
              Authorization: `Bearer ${newsettings.pterodactyl.key}`,
            },
          }
        );
        if (serversResponse.ok) {
          const serversData = await serversResponse.json();
          const servers = serversData.data || [];
          totalServers = servers.length;
          activeServers = servers.filter(
            (s) => s && s.attributes && s.attributes.suspended === false
          ).length;
        }
      } catch (err) {
        console.error("stats: failed to fetch servers", err);
      }

      // Sum total coins across all users (only if coin system enabled)
      let totalCoins = 0;
      if (newsettings.api && newsettings.api.client && newsettings.api.client.coins && newsettings.api.client.coins.enabled) {
        // Iterate via Keyv async iterator if available, otherwise fall back to user list
        let summed = false;
        try {
          if (db && typeof db.iterator === "function") {
            for await (const [key, value] of db.iterator()) {
              if (typeof key === "string" && key.startsWith("coins-")) {
                const num = parseFloat(value);
                if (!isNaN(num)) totalCoins += num;
              }
            }
            summed = true;
          }
        } catch (err) {
          console.error("stats: iterator failed, falling back", err);
        }

        if (!summed) {
          // Fallback: walk all users in panel and look up by username (Discord ID)
          try {
            const panelResponse = await fetch(
              `${newsettings.pterodactyl.domain}/api/application/users?per_page=1000`,
              {
                method: "get",
                headers: {
                  "Content-Type": "application/json",
                  Authorization: `Bearer ${newsettings.pterodactyl.key}`,
                },
              }
            );
            if (panelResponse.ok) {
              const panelData = await panelResponse.json();
              const panelUsers = panelData.data || [];
              for (const pu of panelUsers) {
                const discordId = pu.attributes && pu.attributes.username;
                if (!discordId) continue;
                const c = await db.get("coins-" + discordId);
                const num = parseFloat(c);
                if (!isNaN(num)) totalCoins += num;
              }
            }
          } catch (err) {
            console.error("stats: coin fallback failed", err);
          }
        }
      }

      res.json({
        totalUsers: totalUsers,
        totalServers: totalServers,
        activeServers: activeServers,
        totalCoins: Math.round(totalCoins * 100) / 100,
        coinsEnabled: !!(newsettings.api && newsettings.api.client && newsettings.api.client.coins && newsettings.api.client.coins.enabled),
      });
    } catch (error) {
      console.error("Error fetching admin stats:", error);
      res.status(500).json({ error: "Internal server error", message: error.message });
    }
  });

  // API endpoint to get a single user's full details (for admin edit page)
  app.get("/api/admin/user/:discordId", async (req, res) => {
    if (!req.session.pterodactyl || !req.session.pterodactyl.root_admin) {
      return res.status(403).json({ error: "Unauthorized" });
    }

    try {
      const discordId = req.params.discordId;
      const newsettings = JSON.parse(fs.readFileSync("./settings.json").toString());

      const pteroId = await db.get("users-" + discordId);
      if (!pteroId) {
        return res.status(404).json({ error: "User not found in database" });
      }

      // Fetch user from Pterodactyl panel
      const ptResp = await fetch(
        `${newsettings.pterodactyl.domain}/api/application/users/${pteroId}?include=servers`,
        {
          method: "get",
          headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${newsettings.pterodactyl.key}`,
          },
        }
      );

      if (!ptResp.ok) {
        return res.status(404).json({ error: "User not found on Pterodactyl panel" });
      }

      const ptUser = await ptResp.json();

      const packageName = (await db.get("package-" + discordId)) || newsettings.api.client.packages.default;
      const packageData = newsettings.api.client.packages.list[packageName] || {
        ram: 0, disk: 0, cpu: 0, servers: 0, backups: 0, databases: 0, allocations: 0,
      };

      const extra = (await db.get("extra-" + discordId)) || {
        ram: 0, disk: 0, cpu: 0, servers: 0, backups: 0, databases: 0, allocations: 0,
      };

      // Backfill missing extra fields
      ["ram", "disk", "cpu", "servers", "backups", "databases", "allocations"].forEach(k => {
        if (typeof extra[k] !== "number") extra[k] = 0;
      });

      const coins = newsettings.api.client.coins.enabled
        ? (await db.get("coins-" + discordId)) || 0
        : null;

      const ip = (await db.get("ip-" + discordId)) || null;

      const servers = (ptUser.attributes.relationships && ptUser.attributes.relationships.servers && ptUser.attributes.relationships.servers.data) || [];

      res.json({
        status: "success",
        discordId: discordId,
        pterodactylId: pteroId,
        coinsEnabled: !!newsettings.api.client.coins.enabled,
        coins: coins,
        package: { name: packageName, ...packageData },
        extra: extra,
        ip: ip,
        availablePackages: Object.keys(newsettings.api.client.packages.list),
        packagesList: newsettings.api.client.packages.list,
        user: {
          id: ptUser.attributes.id,
          username: ptUser.attributes.username,
          email: ptUser.attributes.email,
          first_name: ptUser.attributes.first_name,
          last_name: ptUser.attributes.last_name,
          root_admin: ptUser.attributes.root_admin,
          created_at: ptUser.attributes.created_at,
        },
        servers: servers.map(s => ({
          id: s.attributes.id,
          uuid: s.attributes.uuid,
          identifier: s.attributes.identifier,
          name: s.attributes.name,
          suspended: s.attributes.suspended,
          limits: s.attributes.limits,
          feature_limits: s.attributes.feature_limits,
        })),
        serverCount: servers.length,
      });
    } catch (error) {
      console.error("Error fetching user details:", error);
      res.status(500).json({ error: "Internal server error", message: error.message });
    }
  });

  // API endpoint to update a user (coins, package, extras) atomically
  app.post("/api/admin/user/update", async (req, res) => {
    if (!req.session.pterodactyl || !req.session.pterodactyl.root_admin) {
      return res.status(403).json({ error: "Unauthorized" });
    }

    try {
      const { discordId, coins, package: packageName, extra } = req.body || {};

      if (!discordId) {
        return res.status(400).json({ error: "Missing discordId" });
      }

      const pteroId = await db.get("users-" + discordId);
      if (!pteroId) {
        return res.status(404).json({ error: "User not found" });
      }

      const newsettings = JSON.parse(fs.readFileSync("./settings.json").toString());
      const changes = [];

      // Coins
      if (coins !== undefined && coins !== null && coins !== "") {
        const num = parseFloat(coins);
        if (isNaN(num) || num < 0 || num > 999999999999999) {
          return res.status(400).json({ error: "Invalid coins value" });
        }
        if (num === 0) {
          await db.delete("coins-" + discordId);
        } else {
          await db.set("coins-" + discordId, num);
        }
        changes.push(`coins=${num}`);
      }

      // Package
      if (packageName !== undefined) {
        if (packageName === "" || packageName === null) {
          await db.delete("package-" + discordId);
          changes.push("package=default");
        } else {
          if (!newsettings.api.client.packages.list[packageName]) {
            return res.status(400).json({ error: "Invalid package" });
          }
          await db.set("package-" + discordId, packageName);
          changes.push(`package=${packageName}`);
        }
      }

      // Extra resources
      if (extra && typeof extra === "object") {
        const fields = ["ram", "disk", "cpu", "servers", "backups", "databases", "allocations"];
        const merged = (await db.get("extra-" + discordId)) || {
          ram: 0, disk: 0, cpu: 0, servers: 0, backups: 0, databases: 0, allocations: 0,
        };
        for (const f of fields) {
          if (typeof merged[f] !== "number") merged[f] = 0;
          if (extra[f] !== undefined && extra[f] !== null && extra[f] !== "") {
            const v = parseFloat(extra[f]);
            if (isNaN(v) || v < 0 || v > 999999999999999) {
              return res.status(400).json({ error: `Invalid ${f} value` });
            }
            merged[f] = v;
          }
        }
        const allZero = fields.every(f => !merged[f]);
        if (allZero) {
          await db.delete("extra-" + discordId);
        } else {
          await db.set("extra-" + discordId, merged);
        }
        changes.push("extra=" + JSON.stringify(merged));
      }

      // Trigger over-resources suspend check (uses settings.allow.overresourcessuspend)
      try {
        adminjs.suspend && adminjs.suspend(discordId);
      } catch (e) { /* non-fatal */ }

      log(
        "edit user",
        `${req.session.userinfo.username}#${req.session.userinfo.discriminator} edited user \`${discordId}\`: ${changes.join(", ")}`
      );

      res.json({ success: true, changes: changes });
    } catch (error) {
      console.error("Error updating user:", error);
      res.status(500).json({ error: "Internal server error", message: error.message });
    }
  });

  // API endpoint to delete a user (JSON, replaces /remove_account redirect flow)
  app.post("/api/admin/user/delete", async (req, res) => {
    if (!req.session.pterodactyl || !req.session.pterodactyl.root_admin) {
      return res.status(403).json({ error: "Unauthorized" });
    }

    try {
      const { discordId } = req.body || {};
      if (!discordId) {
        return res.status(400).json({ error: "Missing discordId" });
      }

      const pteroId = await db.get("users-" + discordId);
      if (!pteroId) {
        return res.status(404).json({ error: "User not found" });
      }

      // Remove IP record
      const selectedIp = await db.get("ip-" + discordId);
      if (selectedIp) {
        let allips = (await db.get("ips")) || [];
        allips = allips.filter(ip => ip !== selectedIp);
        if (allips.length === 0) {
          await db.delete("ips");
        } else {
          await db.set("ips", allips);
        }
        await db.delete("ip-" + discordId);
      }

      // Remove from users list
      let userids = (await db.get("users")) || [];
      userids = userids.filter(uid => uid !== pteroId);
      if (userids.length === 0) {
        await db.delete("users");
      } else {
        await db.set("users", userids);
      }

      await db.delete("users-" + discordId);
      await db.delete("coins-" + discordId);
      await db.delete("extra-" + discordId);
      await db.delete("package-" + discordId);

      log(
        "remove account",
        `${req.session.userinfo.username}#${req.session.userinfo.discriminator} removed the account with the ID \`${discordId}\`.`
      );

      res.json({ success: true });
    } catch (error) {
      console.error("Error deleting user:", error);
      res.status(500).json({ error: "Internal server error", message: error.message });
    }
  });

  // API endpoint to list all users
  app.get("/api/admin/users", async (req, res) => {
    if (!req.session.pterodactyl || !req.session.pterodactyl.root_admin) {
      return res.status(403).json({ error: "Unauthorized" });
    }

    try {
      const newsettings = JSON.parse(fs.readFileSync("./settings.json").toString());
      const users = [];
      
      // Get all users from Pterodactyl panel
      console.log("Fetching all users from Pterodactyl panel...");
      const panelResponse = await fetch(
        `${newsettings.pterodactyl.domain}/api/application/users?per_page=1000`,
        {
          method: "get",
          headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${newsettings.pterodactyl.key}`,
          },
        }
      );

      if (!panelResponse.ok) {
        console.error("Failed to fetch users from panel:", panelResponse.statusText);
        return res.status(500).json({ error: "Failed to fetch users from panel" });
      }

      const panelData = await panelResponse.json();
      const panelUsers = panelData.data || [];
      
      console.log(`Found ${panelUsers.length} users on Pterodactyl panel`);

      // Get the list of pterodactyl IDs from our database
      const usersList = (await db.get("users")) || [];
      console.log(`Found ${usersList.length} users in local database`);

      // For each panel user, check if they're in our database
      for (const panelUser of panelUsers) {
        const pterodactylId = panelUser.attributes.id;
        
        // Check if this pterodactyl ID is in our database
        if (!usersList.includes(pterodactylId)) {
          continue; // Skip users not in our database
        }

        // The Pterodactyl username is the Discord ID (set during account creation)
        const discordId = panelUser.attributes.username;
        
        // Verify this is the correct mapping
        const storedPteroId = await db.get("users-" + discordId);
        if (storedPteroId !== pterodactylId) {
          console.log(`Mismatch for user ${discordId}: stored=${storedPteroId}, actual=${pterodactylId}`);
          continue; // Skip if mapping doesn't match
        }

        // Get user data from database
        const coins = newsettings.api.client.coins.enabled 
          ? (await db.get("coins-" + discordId)) || 0 
          : null;
        const extra = (await db.get("extra-" + discordId)) || {
          ram: 0,
          disk: 0,
          cpu: 0,
          servers: 0,
        };
        const packageName = await db.get("package-" + discordId);

        users.push({
          discordId: discordId,
          pterodactylId: pterodactylId,
          username: panelUser.attributes.first_name || panelUser.attributes.username,
          email: panelUser.attributes.email,
          coins: coins,
          extra: extra,
          package: packageName || newsettings.api.client.packages.default,
        });
      }

      console.log(`Returning ${users.length} users to frontend`);
      res.json({ users: users });
    } catch (error) {
      console.error("Error fetching users:", error);
      res.status(500).json({ error: "Internal server error", message: error.message });
    }
  });

  // API endpoint to list all servers
  app.get("/api/admin/servers", async (req, res) => {
    if (!req.session.pterodactyl || !req.session.pterodactyl.root_admin) {
      return res.status(403).json({ error: "Unauthorized" });
    }

    try {
      const newsettings = JSON.parse(fs.readFileSync("./settings.json").toString());
      
      // Fetch all servers from Pterodactyl panel
      console.log("Fetching all servers from Pterodactyl panel...");
      const serversResponse = await fetch(
        `${newsettings.pterodactyl.domain}/api/application/servers?per_page=1000`,
        {
          method: "get",
          headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${newsettings.pterodactyl.key}`,
          },
        }
      );

      if (!serversResponse.ok) {
        console.error("Failed to fetch servers from panel:", serversResponse.statusText);
        return res.status(500).json({ error: "Failed to fetch servers from panel" });
      }

      const serversData = await serversResponse.json();
      const servers = serversData.data || [];
      
      console.log(`Found ${servers.length} servers on Pterodactyl panel`);

      // Format server data
      const formattedServers = servers.map(server => {
        const attrs = server.attributes;

        // Derive a reliable lifecycle status from the Application API.
        // (Real-time power state requires the Client API + a per-user client key,
        // which an application key cannot impersonate.)
        let status;
        if (attrs.suspended) {
          status = 'suspended';
        } else if (attrs.status === 'installing') {
          status = 'installing';
        } else if (attrs.status === 'install_failed' || attrs.status === 'reinstall_failed') {
          status = 'install_failed';
        } else if (attrs.status === 'restoring_backup') {
          status = 'restoring';
        } else if (attrs.status === 'transferring') {
          status = 'transferring';
        } else {
          status = 'active';
        }

        return {
          id: attrs.id,
          uuid: attrs.uuid,
          identifier: attrs.identifier,
          name: attrs.name,
          description: attrs.description,
          status: status,
          suspended: !!attrs.suspended,
          user_id: attrs.user,
          node_id: attrs.node,
          limits: {
            memory: attrs.limits.memory,
            disk: attrs.limits.disk,
            cpu: attrs.limits.cpu,
          },
          feature_limits: attrs.feature_limits,
          created_at: attrs.created_at,
        };
      });

      console.log(`Returning ${formattedServers.length} servers to frontend`);
      res.json({ servers: formattedServers });
    } catch (error) {
      console.error("Error fetching servers:", error);
      res.status(500).json({ error: "Internal server error", message: error.message });
    }
  });

  // API endpoint to suspend/unsuspend server
  app.post("/api/admin/server/suspend", async (req, res) => {
    if (!req.session.pterodactyl || !req.session.pterodactyl.root_admin) {
      return res.status(403).json({ error: "Unauthorized" });
    }

    try {
      const serverId = req.body.id;
      const action = req.body.action; // 'suspend' or 'unsuspend'
      
      if (!serverId || !action) {
        return res.status(400).json({ error: "Missing server ID or action" });
      }

      const newsettings = JSON.parse(fs.readFileSync("./settings.json").toString());
      
      const endpoint = action === 'suspend' ? 'suspend' : 'unsuspend';
      const response = await fetch(
        `${newsettings.pterodactyl.domain}/api/application/servers/${serverId}/${endpoint}`,
        {
          method: "post",
          headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${newsettings.pterodactyl.key}`,
          },
        }
      );

      if (!response.ok) {
        return res.status(response.status).json({ error: `Failed to ${action} server` });
      }

      // Track suspension reason so the renewal flow knows whether it's safe
      // to auto-unsuspend on renew. Manual admin suspensions are NOT cleared
      // by a regular user renewal — admins must unsuspend explicitly.
      if (action === "suspend") {
        await db.set(`server-suspend-reason-${serverId}`, "manual");
      } else {
        await db.delete(`server-suspend-reason-${serverId}`);
      }

      log(
        `${action} server`,
        `${req.session.userinfo.username}#${req.session.userinfo.discriminator} ${action}ed server with ID \`${serverId}\`.`
      );

      res.json({ success: true, message: `Server ${action}ed successfully` });
    } catch (error) {
      console.error("Error suspending/unsuspending server:", error);
      res.status(500).json({ error: "Internal server error", message: error.message });
    }
  });

  // API endpoint for admin to delete a server by ID
  app.delete("/api/admin/server/:id", async (req, res) => {
    if (!req.session.pterodactyl || !req.session.pterodactyl.root_admin) {
      return res.status(403).json({ error: "Unauthorized" });
    }

    try {
      const serverId = req.params.id;
      if (!serverId) {
        return res.status(400).json({ error: "Missing server ID" });
      }

      const newsettings = JSON.parse(fs.readFileSync("./settings.json").toString());

      const deletionResponse = await fetch(
        `${newsettings.pterodactyl.domain}/api/application/servers/${serverId}`,
        {
          method: "delete",
          headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${newsettings.pterodactyl.key}`,
          },
        }
      );

      if (!deletionResponse.ok) {
        return res
          .status(deletionResponse.status)
          .json({ error: "Failed to delete server on Pterodactyl panel" });
      }

      log(
        `delete server`,
        `${req.session.userinfo.username}#${req.session.userinfo.discriminator} deleted server with ID \`${serverId}\`.`
      );

      res.json({ success: true, message: "Server deleted successfully" });
    } catch (error) {
      console.error("Error deleting server:", error);
      res.status(500).json({ error: "Internal server error", message: error.message });
    }
  });

  // API endpoint for admin to delete all suspended servers in one shot
  app.post("/api/admin/servers/delete-suspended", async (req, res) => {
    if (!req.session.pterodactyl || !req.session.pterodactyl.root_admin) {
      return res.status(403).json({ error: "Unauthorized" });
    }

    try {
      const newsettings = JSON.parse(fs.readFileSync("./settings.json").toString());

      // Fetch all servers and pick the suspended ones
      const serversResponse = await fetch(
        `${newsettings.pterodactyl.domain}/api/application/servers?per_page=1000`,
        {
          method: "get",
          headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${newsettings.pterodactyl.key}`,
          },
        }
      );

      if (!serversResponse.ok) {
        return res.status(500).json({ error: "Failed to fetch servers from panel" });
      }

      const serversData = await serversResponse.json();
      const suspendedServers = (serversData.data || []).filter(
        (s) => s.attributes && s.attributes.suspended
      );

      let deletedCount = 0;
      const failed = [];

      for (const server of suspendedServers) {
        const serverId = server.attributes.id;
        try {
          const deletionResponse = await fetch(
            `${newsettings.pterodactyl.domain}/api/application/servers/${serverId}`,
            {
              method: "delete",
              headers: {
                "Content-Type": "application/json",
                Authorization: `Bearer ${newsettings.pterodactyl.key}`,
              },
            }
          );

          if (deletionResponse.ok) {
            deletedCount++;
          } else {
            failed.push({ id: serverId, status: deletionResponse.status });
          }
        } catch (err) {
          failed.push({ id: serverId, error: err.message });
        }
      }

      log(
        `delete suspended servers`,
        `${req.session.userinfo.username}#${req.session.userinfo.discriminator} deleted ${deletedCount} suspended server(s) (${failed.length} failed).`
      );

      res.json({
        success: true,
        totalSuspended: suspendedServers.length,
        deleted: deletedCount,
        failed,
      });
    } catch (error) {
      console.error("Error deleting suspended servers:", error);
      res.status(500).json({ error: "Internal server error", message: error.message });
    }
  });

  // API endpoint for admin to renew server
  app.post("/api/admin/server/renew", async (req, res) => {
    if (!req.session.pterodactyl || !req.session.pterodactyl.root_admin) {
      return res.status(403).json({ error: "Unauthorized" });
    }

    try {
      const { serverId, days } = req.body;
      
      if (!serverId || !days || days < 1) {
        return res.status(400).json({ error: "Invalid request" });
      }

      const newsettings = JSON.parse(fs.readFileSync("./settings.json").toString());
      
      // Get current expiry or set to now if expired
      const currentExpiry = await db.get(`server-expiry-${serverId}`) || Date.now();
      const now = Date.now();
      const baseTime = currentExpiry > now ? currentExpiry : now;
      
      // Add days to expiry
      const newExpiry = baseTime + (days * 24 * 60 * 60 * 1000);
      await db.set(`server-expiry-${serverId}`, newExpiry);
      
      // Admin renewal always unsuspends the server (admins explicitly chose to
      // renew it). The unsuspend response is verified and reported back so the
      // UI can show a meaningful message if it failed.
      let wasSuspended = false;
      let unsuspended = false;
      let unsuspendError = null;

      const serverInfo = await fetch(
        `${newsettings.pterodactyl.domain}/api/application/servers/${serverId}`,
        {
          method: "get",
          headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${newsettings.pterodactyl.key}`,
          },
        }
      );
      
      if (serverInfo.ok) {
        const serverData = await serverInfo.json();
        wasSuspended = !!serverData.attributes.suspended;

        if (wasSuspended) {
          const unsuspendResp = await fetch(
            `${newsettings.pterodactyl.domain}/api/application/servers/${serverId}/unsuspend`,
            {
              method: "post",
              headers: {
                "Content-Type": "application/json",
                Authorization: `Bearer ${newsettings.pterodactyl.key}`,
              },
            }
          );

          if (unsuspendResp.ok) {
            unsuspended = true;
            await db.delete(`server-suspend-reason-${serverId}`);
          } else {
            unsuspendError = `Pterodactyl returned ${unsuspendResp.status}`;
            console.error(
              `Admin renewal: failed to unsuspend server ${serverId}: ${unsuspendError}`
            );
          }
        }
      } else {
        unsuspendError = `Failed to fetch server status (Pterodactyl returned ${serverInfo.status})`;
        console.error(unsuspendError);
      }
      
      log(
        "admin renewed server",
        `${req.session.userinfo.username}#${req.session.userinfo.discriminator} renewed server ${serverId} for ${days} days (Admin action - no coins charged, wasSuspended=${wasSuspended}, unsuspended=${unsuspended})`
      );
      
      res.json({
        success: true,
        newExpiry: newExpiry,
        daysAdded: days,
        wasSuspended,
        unsuspended,
        unsuspendError
      });
    } catch (error) {
      console.error("Error renewing server:", error);
      res.status(500).json({ error: "Internal server error" });
    }
  });

  // API endpoint to update server duration settings
  app.post("/api/admin/duration/settings", async (req, res) => {
    if (!req.session.pterodactyl || !req.session.pterodactyl.root_admin) {
      return res.status(403).json({ error: "Unauthorized" });
    }

    try {
      const { enabled, defaultDays, renewalCostPerDay, autoSuspend, warningDays, checkIntervalMinutes } = req.body;
      
      const settingsPath = "./settings.json";
      const settings = JSON.parse(fs.readFileSync(settingsPath));

      if (!settings.api.client.serverDuration) {
        settings.api.client.serverDuration = {};
      }

      if (enabled !== undefined) settings.api.client.serverDuration.enabled = enabled;
      if (defaultDays !== undefined) settings.api.client.serverDuration.defaultDays = parseInt(defaultDays);
      if (renewalCostPerDay !== undefined) settings.api.client.serverDuration.renewalCostPerDay = parseInt(renewalCostPerDay);
      if (autoSuspend !== undefined) settings.api.client.serverDuration.autoSuspend = autoSuspend;
      if (warningDays !== undefined) settings.api.client.serverDuration.warningDays = parseInt(warningDays);
      if (checkIntervalMinutes !== undefined) settings.api.client.serverDuration.checkIntervalMinutes = parseInt(checkIntervalMinutes);

      fs.writeFileSync(settingsPath, JSON.stringify(settings, null, 2));
      
      log(
        "update duration settings",
        `${req.session.userinfo.username}#${req.session.userinfo.discriminator} updated server duration settings`
      );
      
      res.json({ success: true, message: "Settings updated successfully" });
    } catch (error) {
      console.error("Error updating duration settings:", error);
      res.status(500).json({ error: "Internal server error" });
    }
  });

  async function four0four(req, res, theme) {
    ejs.renderFile(
      `./views/${theme.settings.notfound}`,
      await eval(indexjs.renderdataeval),
      null,
      function (err, str) {
        delete req.session.newaccount;
        if (err) {
          console.log(
            `App ― An error has occured on path ${req._parsedUrl.pathname}:`
          );
          console.log(err);
          return res.send("Internal Server Error");
        }
        res.status(404);
        res.send(str);
      }
    );
  }

  module.exports.suspend = async function (discordid) {
    let newsettings = JSON.parse(fs.readFileSync("./settings.json").toString());
    if (newsettings.api.client.allow.overresourcessuspend !== true) return;

    let canpass = await indexjs.islimited();
    if (canpass == false) {
      setTimeout(async function () {
        adminjs.suspend(discordid);
      }, 1);
      return;
    }

    indexjs.ratelimits(1);
    let pterodactylid = await db.get("users-" + discordid);
    let userinforeq = await fetch(
      settings.pterodactyl.domain +
        "/api/application/users/" +
        pterodactylid +
        "?include=servers",
      {
        method: "get",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${settings.pterodactyl.key}`,
        },
      }
    );
    if ((await userinforeq.statusText) == "Not Found") {
      console.log(
        "App ― An error has occured while attempting to check if a user's server should be suspended."
      );
      console.log("- Discord ID: " + discordid);
      console.log("- Pterodactyl Panel ID: " + pterodactylid);
      return;
    }
    let userinfo = JSON.parse(await userinforeq.text());

    let packagename = await db.get("package-" + discordid);
    let package =
      newsettings.api.client.packages.list[
        packagename || newsettings.api.client.packages.default
      ];

    let extra = (await db.get("extra-" + discordid)) || {
      ram: 0,
      disk: 0,
      cpu: 0,
      servers: 0,
    };

    let plan = {
      ram: package.ram + extra.ram,
      disk: package.disk + extra.disk,
      cpu: package.cpu + extra.cpu,
      servers: package.servers + extra.servers,
    };

    let current = {
      ram: 0,
      disk: 0,
      cpu: 0,
      servers: userinfo.attributes.relationships.servers.data.length,
    };
    for (
      let i = 0, len = userinfo.attributes.relationships.servers.data.length;
      i < len;
      i++
    ) {
      current.ram =
        current.ram +
        userinfo.attributes.relationships.servers.data[i].attributes.limits
          .memory;
      current.disk =
        current.disk +
        userinfo.attributes.relationships.servers.data[i].attributes.limits
          .disk;
      current.cpu =
        current.cpu +
        userinfo.attributes.relationships.servers.data[i].attributes.limits.cpu;
    }

    indexjs.ratelimits(userinfo.attributes.relationships.servers.data.length);
    if (
      current.ram > plan.ram ||
      current.disk > plan.disk ||
      current.cpu > plan.cpu ||
      current.servers > plan.servers
    ) {
      for (
        let i = 0, len = userinfo.attributes.relationships.servers.data.length;
        i < len;
        i++
      ) {
        let suspendid =
          userinfo.attributes.relationships.servers.data[i].attributes.id;
        await fetch(
          settings.pterodactyl.domain +
            "/api/application/servers/" +
            suspendid +
            "/suspend",
          {
            method: "post",
            headers: {
              "Content-Type": "application/json",
              Authorization: `Bearer ${settings.pterodactyl.key}`,
            },
          }
        );
      }
    } else {
      if (settings.api.client.allow.renewsuspendsystem.enabled == true) return;
      for (
        let i = 0, len = userinfo.attributes.relationships.servers.data.length;
        i < len;
        i++
      ) {
        let suspendid =
          userinfo.attributes.relationships.servers.data[i].attributes.id;
        await fetch(
          settings.pterodactyl.domain +
            "/api/application/servers/" +
            suspendid +
            "/unsuspend",
          {
            method: "post",
            headers: {
              "Content-Type": "application/json",
              Authorization: `Bearer ${settings.pterodactyl.key}`,
            },
          }
        );
      }
    }
  };

  // API endpoint to list all coupons
  app.get("/api/admin/coupons", async (req, res) => {
    if (!req.session.pterodactyl || !req.session.pterodactyl.root_admin) {
      return res.status(403).json({ error: "Unauthorized" });
    }

    try {
      // Get all keys that start with "coupon-"
      const allKeys = [];
      // Since Keyv doesn't have a keys() method, we'll need to track coupons separately
      const couponList = await db.get("coupon-list") || [];
      
      const coupons = [];
      for (const code of couponList) {
        const coupon = await db.get(`coupon-${code}`);
        if (coupon) {
          coupons.push({
            code: code,
            ...coupon
          });
        }
      }

      res.json({ coupons: coupons });
    } catch (error) {
      console.error("Error fetching coupons:", error);
      res.status(500).json({ error: "Internal server error" });
    }
  });

  // API endpoint to create a coupon
  app.post("/api/admin/coupon/create", async (req, res) => {
    if (!req.session.pterodactyl || !req.session.pterodactyl.root_admin) {
      return res.status(403).json({ error: "Unauthorized" });
    }

    try {
      const { code, coins, duration, maxUses } = req.body;
      
      if (!code || !coins) {
        return res.status(400).json({ error: "Code and coins are required" });
      }

      const couponCode = code.toUpperCase().trim();
      
      // Check if coupon already exists
      const existing = await db.get(`coupon-${couponCode}`);
      if (existing) {
        return res.status(400).json({ error: "Coupon code already exists" });
      }

      // Calculate expiry date
      let expiresAt = null;
      if (duration && duration > 0) {
        expiresAt = Date.now() + (duration * 24 * 60 * 60 * 1000); // duration in days
      }

      const coupon = {
        coins: parseInt(coins),
        createdAt: Date.now(),
        expiresAt: expiresAt,
        maxUses: maxUses ? parseInt(maxUses) : null,
        usedCount: 0,
        createdBy: req.session.userinfo.username
      };

      await db.set(`coupon-${couponCode}`, coupon);
      
      // Add to coupon list
      const couponList = await db.get("coupon-list") || [];
      if (!couponList.includes(couponCode)) {
        couponList.push(couponCode);
        await db.set("coupon-list", couponList);
      }

      log(
        "create coupon",
        `${req.session.userinfo.username}#${req.session.userinfo.discriminator} created coupon \`${couponCode}\` with ${coins} coins${duration ? `, expires in ${duration} days` : ''}${maxUses ? `, max uses: ${maxUses}` : ''}`
      );

      res.json({ success: true, coupon: { code: couponCode, ...coupon } });
    } catch (error) {
      console.error("Error creating coupon:", error);
      res.status(500).json({ error: "Internal server error" });
    }
  });

  // API endpoint to delete a coupon
  app.delete("/api/admin/coupon/:code", async (req, res) => {
    if (!req.session.pterodactyl || !req.session.pterodactyl.root_admin) {
      return res.status(403).json({ error: "Unauthorized" });
    }

    try {
      const couponCode = req.params.code.toUpperCase();
      
      const coupon = await db.get(`coupon-${couponCode}`);
      if (!coupon) {
        return res.status(404).json({ error: "Coupon not found" });
      }

      await db.delete(`coupon-${couponCode}`);
      
      // Remove from coupon list
      const couponList = await db.get("coupon-list") || [];
      const updatedList = couponList.filter(c => c !== couponCode);
      await db.set("coupon-list", updatedList);

      log(
        "delete coupon",
        `${req.session.userinfo.username}#${req.session.userinfo.discriminator} deleted coupon \`${couponCode}\``
      );

      res.json({ success: true });
    } catch (error) {
      console.error("Error deleting coupon:", error);
      res.status(500).json({ error: "Internal server error" });
    }
  });

  // API endpoint to edit a coupon
  app.put("/api/admin/coupon/:code", async (req, res) => {
    if (!req.session.pterodactyl || !req.session.pterodactyl.root_admin) {
      return res.status(403).json({ error: "Unauthorized" });
    }

    try {
      const couponCode = req.params.code.toUpperCase();
      const { coins, duration, maxUses } = req.body;
      
      const coupon = await db.get(`coupon-${couponCode}`);
      if (!coupon) {
        return res.status(404).json({ error: "Coupon not found" });
      }

      // Update coupon properties
      if (coins !== undefined) coupon.coins = parseInt(coins);
      if (maxUses !== undefined) coupon.maxUses = maxUses ? parseInt(maxUses) : null;
      
      if (duration !== undefined) {
        if (duration > 0) {
          coupon.expiresAt = Date.now() + (duration * 24 * 60 * 60 * 1000);
        } else {
          coupon.expiresAt = null;
        }
      }

      await db.set(`coupon-${couponCode}`, coupon);

      log(
        "edit coupon",
        `${req.session.userinfo.username}#${req.session.userinfo.discriminator} edited coupon \`${couponCode}\``
      );

      res.json({ success: true, coupon: { code: couponCode, ...coupon } });
    } catch (error) {
      console.error("Error editing coupon:", error);
      res.status(500).json({ error: "Internal server error" });
    }
  });

  // API endpoint to update video background
  app.post("/admin/update-video-background", async (req, res) => {
    if (!req.session.pterodactyl || !req.session.pterodactyl.root_admin) {
      return res.status(403).send("Unauthorized");
    }

    try {
      const { videoBackground } = req.body;
      
      const settingsPath = "./settings.json";
      const settings = JSON.parse(fs.readFileSync(settingsPath));

      if (!settings.branding) {
        settings.branding = {};
      }

      settings.branding.videoBackground = videoBackground || "";

      fs.writeFileSync(settingsPath, JSON.stringify(settings, null, 2));
      
      log(
        "update video background",
        `${req.session.userinfo.username}#${req.session.userinfo.discriminator} updated video background URL`
      );
      
      res.redirect("/admin/customize?success=true");
    } catch (error) {
      console.error("Error updating video background:", error);
      res.status(500).send("Internal Server Error");
    }
  });

  // API endpoint to update server duration settings
  app.post("/admin/update-server-duration", async (req, res) => {
    if (!req.session.pterodactyl || !req.session.pterodactyl.root_admin) {
      return res.status(403).send("Unauthorized");
    }

    try {
      const { durationEnabled, defaultDays, renewalCostPerDay, autoDeleteEnabled, autoDeleteDays } = req.body;
      
      const settingsPath = "./settings.json";
      const settings = JSON.parse(fs.readFileSync(settingsPath));

      if (!settings.api) {
        settings.api = {};
      }
      if (!settings.api.client) {
        settings.api.client = {};
      }
      if (!settings.api.client.serverDuration) {
        settings.api.client.serverDuration = {};
      }
      if (!settings.api.client.serverDuration.autoDelete) {
        settings.api.client.serverDuration.autoDelete = {};
      }

      settings.api.client.serverDuration.enabled = durationEnabled === 'on';
      settings.api.client.serverDuration.defaultDays = parseInt(defaultDays) || 7;
      settings.api.client.serverDuration.renewalCostPerDay = parseInt(renewalCostPerDay) || 10;

      settings.api.client.serverDuration.autoDelete.enabled = autoDeleteEnabled === 'on';
      const parsedAutoDeleteDays = parseInt(autoDeleteDays);
      settings.api.client.serverDuration.autoDelete.daysAfterSuspend =
        Number.isFinite(parsedAutoDeleteDays) && parsedAutoDeleteDays >= 0
          ? parsedAutoDeleteDays
          : 3;

      fs.writeFileSync(settingsPath, JSON.stringify(settings, null, 2));
      
      log(
        "update server duration settings",
        `${req.session.userinfo.username}#${req.session.userinfo.discriminator} updated server duration settings: ` +
          `enabled=${settings.api.client.serverDuration.enabled}, ` +
          `defaultDays=${settings.api.client.serverDuration.defaultDays}, ` +
          `renewalCost=${settings.api.client.serverDuration.renewalCostPerDay}, ` +
          `autoDelete=${settings.api.client.serverDuration.autoDelete.enabled}, ` +
          `autoDeleteDays=${settings.api.client.serverDuration.autoDelete.daysAfterSuspend}`
      );
      
      res.redirect("/admin/customize?success=true");
    } catch (error) {
      console.error("Error updating server duration settings:", error);
      res.status(500).send("Internal Server Error");
    }
  });

  // API endpoint to update resource store pricing
  app.post("/admin/update-store-prices", async (req, res) => {
    if (!req.session.pterodactyl || !req.session.pterodactyl.root_admin) {
      return res.status(403).send("Unauthorized");
    }

    try {
      const settingsPath = "./settings.json";
      const settings = JSON.parse(fs.readFileSync(settingsPath));

      if (!settings.api) settings.api = {};
      if (!settings.api.client) settings.api.client = {};
      if (!settings.api.client.coins) settings.api.client.coins = {};
      if (!settings.api.client.coins.store) settings.api.client.coins.store = {};

      const store = settings.api.client.coins.store;
      const types = [
        { key: "ram", costField: "ramCost", perField: "ramPer", minPer: 1 },
        { key: "disk", costField: "diskCost", perField: "diskPer", minPer: 1 },
        { key: "cpu", costField: "cpuCost", perField: "cpuPer", minPer: 1 },
        { key: "servers", costField: "serversCost", perField: "serversPer", minPer: 1 },
        { key: "backups", costField: "backupsCost", perField: "backupsPer", minPer: 1 },
        { key: "databases", costField: "databasesCost", perField: "databasesPer", minPer: 1 },
        { key: "allocations", costField: "allocationsCost", perField: "allocationsPer", minPer: 1 },
      ];

      for (const t of types) {
        const rawCost = req.body[t.costField];
        const rawPer = req.body[t.perField];
        if (rawCost === undefined && rawPer === undefined) continue;
        const cost = parseInt(rawCost);
        const per = parseInt(rawPer);
        if (isNaN(cost) || isNaN(per) || cost < 0 || per < t.minPer) {
          return res.status(400).send(`Invalid value for ${t.key}: cost must be >= 0, per must be >= ${t.minPer}`);
        }
        store[t.key] = { cost: cost, per: per };
      }

      fs.writeFileSync(settingsPath, JSON.stringify(settings, null, 2));

      log(
        "update store pricing",
        `${req.session.userinfo.username}#${req.session.userinfo.discriminator} updated resource store pricing.`
      );

      res.redirect("/admin/customize?success=true");
    } catch (error) {
      console.error("Error updating store pricing:", error);
      res.status(500).send("Internal Server Error");
    }
  });
};
